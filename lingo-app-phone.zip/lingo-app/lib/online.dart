import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

/// 联网补充：Free Dictionary API（真人发音/例句/英文释义）+ Wikipedia（配图）。结果缓存到本机，之后离线也能用。
class Online {
  static const _h = {'User-Agent': 'LingoApp/0.3 (language learning app)'};

  static String _safe(String w) => w.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_');

  static Future<Directory> _dir() async {
    final d = Directory('${(await getApplicationSupportDirectory()).path}/cache');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<Map<String, dynamic>> _dict(String enc) async {
    final out = <String, dynamic>{};
    try {
      final r = await http.get(Uri.parse('https://api.dictionaryapi.dev/api/v2/entries/en/$enc'), headers: _h)
          .timeout(const Duration(seconds: 6));
      if (r.statusCode == 200) {
        final e = (jsonDecode(r.body) as List).first as Map<String, dynamic>;
        for (final ph in (e['phonetics'] as List? ?? [])) {
          final a = '${ph['audio'] ?? ''}';
          final t = '${ph['text'] ?? ''}';
          if (out['audio'] == null && a.isNotEmpty) out['audio'] = a.startsWith('//') ? 'https:$a' : a;
          if (out['ipa'] == null && t.isNotEmpty) out['ipa'] = t;
        }
        for (final m in (e['meanings'] as List? ?? [])) {
          for (final d in (m['definitions'] as List? ?? [])) {
            out['def'] ??= d['definition'];
            if (out['example'] == null && d['example'] != null) out['example'] = d['example'];
          }
        }
      }
    } catch (_) {}
    return out;
  }

  static Future<Map<String, dynamic>> _wiki(String enc) async {
    final out = <String, dynamic>{};
    try {
      final r = await http.get(Uri.parse('https://en.wikipedia.org/api/rest_v1/page/summary/$enc'), headers: _h)
          .timeout(const Duration(seconds: 6));
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        if (j['type'] == 'standard' && j['thumbnail'] != null) out['image'] = j['thumbnail']['source'];
      }
    } catch (_) {}
    return out;
  }

  /// 先读本机缓存；没有再联网取。离线且无缓存时返回 null。
  static Future<Map<String, dynamic>?> info(String word) async {
    final f = File('${(await _dir()).path}/${_safe(word)}.json');
    if (await f.exists()) return jsonDecode(await f.readAsString()) as Map<String, dynamic>;
    final enc = Uri.encodeComponent(word);
    final res = await Future.wait([_dict(enc), _wiki(enc)]);
    final out = {...res[0], ...res[1]};
    if (out.isEmpty) return null;
    await f.writeAsString(jsonEncode(out));
    return out;
  }

  static Future<String?> cachedAudio(String w) async {
    final f = File('${(await _dir()).path}/${_safe(w)}.mp3');
    return await f.exists() ? f.path : null;
  }

  static Future<String?> downloadAudio(String w, String url) async {
    try {
      final r = await http.get(Uri.parse(url), headers: _h).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return null;
      final f = File('${(await _dir()).path}/${_safe(w)}.mp3');
      await f.writeAsBytes(r.bodyBytes);
      return f.path;
    } catch (_) {
      return null;
    }
  }
}
