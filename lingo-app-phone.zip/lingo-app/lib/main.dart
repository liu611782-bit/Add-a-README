import 'package:flutter/material.dart';
import 'models.dart';
import 'practice_page.dart';
import 'video_page.dart';
import 'word_page.dart';

void main() => runApp(const LingoApp());

class LingoApp extends StatelessWidget {
  const LingoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Lingo',
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Lang> langs = [];
  List<Lesson> lessons = [];
  List<Word> words = [];
  Lang? lang;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final l = await PackRepo.langs();
    final v = await PackRepo.lessons();
    setState(() {
      langs = l;
      lessons = v;
    });
    await _pick(l.first);
  }

  Future<void> _pick(Lang l) async {
    final w = await PackRepo.words(l);
    setState(() {
      lang = l;
      words = w;
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = lang;
    if (l == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final pages = [
      WordList(key: ValueKey('list-${l.code}'), words: words, lang: l),
      PracticePage(key: ValueKey('practice-${l.code}'), words: words, lang: l),
      VideoList(lessons: lessons),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(l.name), actions: [
        PopupMenuButton<Lang>(
          icon: const Icon(Icons.language),
          tooltip: '切换语言',
          onSelected: _pick,
          itemBuilder: (_) => [for (final x in langs) PopupMenuItem(value: x, child: Text(x.name))],
        ),
      ]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book), label: '词汇'),
          NavigationDestination(icon: Icon(Icons.headphones), label: '听读'),
          NavigationDestination(icon: Icon(Icons.ondemand_video), label: '视频'),
        ],
      ),
    );
  }
}

class WordList extends StatefulWidget {
  final List<Word> words;
  final Lang lang;
  const WordList({super.key, required this.words, required this.lang});
  @override
  State<WordList> createState() => _WordListState();
}

class _WordListState extends State<WordList> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final k = q.toLowerCase();
    final shown = widget.words.where((w) => w.word.toLowerCase().contains(k) || w.zh.contains(q)).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索单词或中文', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => q = v),
        ),
      ),
      Expanded(
        child: ListView(children: [
          for (final w in shown)
            ListTile(
              leading: Text(w.emoji, style: const TextStyle(fontSize: 32)),
              title: Text(w.word),
              subtitle: Text('${w.ipa}   ${w.zh}'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WordPage(w, widget.lang))),
            ),
        ]),
      ),
    ]);
  }
}
