import 'package:flutter/material.dart';
import 'models.dart';
import 'practice_page.dart';
import 'video_page.dart';
import 'word_page.dart';

void main() => runApp(const LingoApp());

class LingoApp extends StatelessWidget {
  const LingoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Lingo',
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Lang> langs = [];
  List<Lesson> lessons = [];
  Lang? lang;
  String level = '';
  int tab = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final l = await PackRepo.langs();
    final v = await PackRepo.lessons();
    setState(() {
      langs = l;
      lessons = v;
      lang = l.first;
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = lang;
    if (l == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final showLevels = l.code == 'en' && tab < 2;
    final pages = [
      WordList(key: ValueKey('list-${l.code}-$level'), lang: l, level: level),
      PracticePage(key: ValueKey('practice-${l.code}-$level'), lang: l, level: level),
      VideoList(lessons: lessons),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(l.name), actions: [
        PopupMenuButton<Lang>(
          icon: const Icon(Icons.language),
          tooltip: '切换语言',
          onSelected: (x) => setState(() {
            lang = x;
            level = '';
          }),
          itemBuilder: (_) => [for (final x in langs) PopupMenuItem(value: x, child: Text(x.name))],
        ),
      ]),
      body: Column(children: [
        if (showLevels)
          SizedBox(
            height: 52,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), children: [
              for (final x in levels)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: Text(x[0]), selected: level == x[1], onSelected: (_) => setState(() => level = x[1])),
                ),
            ]),
          ),
        Expanded(child: pages[tab]),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book), label: '词汇'),
          NavigationDestination(icon: Icon(Icons.headphones), label: '听读'),
          NavigationDestination(icon: Icon(Icons.ondemand_video), label: '视频资源'),
        ],
      ),
    );
  }
}

/// 分页词表：滚动到底自动加载更多，支持搜索。
class WordList extends StatefulWidget {
  final Lang lang;
  final String level;
  const WordList({super.key, required this.lang, required this.level});
  @override
  State<WordList> createState() => _WordListState();
}

class _WordListState extends State<WordList> {
  final items = <Word>[];
  final sc = ScrollController();
  String q = '';
  bool loading = false, done = false;

  @override
  void initState() {
    super.initState();
    sc.addListener(() {
      if (sc.position.pixels > sc.position.maxScrollExtent - 300) _more();
    });
    _more();
  }

  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  Future<void> _more() async {
    if (loading || done) return;
    loading = true;
    final cur = q;
    final r = await PackRepo.page(widget.lang, level: widget.level, q: cur, offset: items.length);
    if (!mounted || cur != q) {
      loading = false;
      return;
    }
    setState(() {
      items.addAll(r);
      done = r.length < 50;
      loading = false;
    });
  }

  void _search(String v) {
    q = v;
    items.clear();
    done = false;
    loading = false;
    setState(() {});
    _more();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
        child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索单词或中文', border: OutlineInputBorder()),
          onChanged: _search,
        ),
      ),
      Expanded(
        child: items.isEmpty && done
            ? const Center(child: Text('没有结果'))
            : ListView.builder(
                controller: sc,
                itemCount: items.length + (done ? 0 : 1),
                itemBuilder: (c, i) {
                  if (i == items.length) {
                    return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                  }
                  final w = items[i];
                  return ListTile(
                    leading: Text(w.emoji, style: const TextStyle(fontSize: 28)),
                    title: Text(w.word),
                    subtitle: Text('${w.ipa}  ${w.zh.split('\n').first}', maxLines: 1, overflow: TextOverflow.ellipsis),
                    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => WordPage(w, widget.lang))),
                  );
                },
              ),
      ),
    ]);
  }
}
