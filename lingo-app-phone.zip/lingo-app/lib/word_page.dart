import 'package:flutter/material.dart';
import 'models.dart';
import 'online.dart';
import 'speaker.dart';
import 'video_page.dart';

class WordPage extends StatefulWidget {
  final Word w;
  final Lang lang;
  const WordPage(this.w, this.lang, {super.key});
  @override
  State<WordPage> createState() => _WordPageState();
}

class _WordPageState extends State<WordPage> {
  Map<String, dynamic>? info;
  bool loading = false;
  Word get w => widget.w;

  @override
  void initState() {
    super.initState();
    if (widget.lang.code == 'en') {
      loading = true;
      Online.info(w.word).then((r) {
        if (mounted) setState(() {
          info = r;
          loading = false;
        });
      });
    }
  }

  Future<void> _say({bool slow = false, bool example = false}) async {
    final ex = (info?['example'] as String?) ?? w.example;
    final ok = example ? await Speaker.say(ex, widget.lang.tts) : await Speaker.playWord(w, widget.lang, slow: slow);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('手机缺少该语言的语音：系统设置 → 文字转语音 → 下载语音数据')));
    }
  }

  Widget _picture() {
    final emoji = Text(w.emoji, style: const TextStyle(fontSize: 96));
    final src = (info?['image'] as String?) ?? w.image;
    if (src == null) return emoji;
    return SizedBox(
      height: 180,
      child: src.startsWith('http')
          ? Image.network(src, errorBuilder: (_, __, ___) => emoji)
          : Image.asset(src, errorBuilder: (_, __, ___) => emoji),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    final ipa = w.ipa.isNotEmpty ? w.ipa : ((info?['ipa'] as String?) ?? '');
    final ex = (info?['example'] as String?) ?? w.example;
    final def = info?['def'] as String?;
    final labels = [for (final k in w.tags.trim().split(' ')) if (tagNames.containsKey(k)) tagNames[k]!];
    return Scaffold(
      appBar: AppBar(title: Text(w.word)),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Center(child: _picture()),
        const SizedBox(height: 16),
        Center(child: Text(w.word, style: t.displaySmall)),
        if (ipa.isNotEmpty) Center(child: Text(ipa, style: t.titleLarge)),
        const SizedBox(height: 12),
        Wrap(alignment: WrapAlignment.center, spacing: 8, children: [for (final s in w.syllables) Chip(label: Text(s))]),
        if (labels.isNotEmpty) ...[
          const SizedBox(height: 8),
          Wrap(alignment: WrapAlignment.center, spacing: 6, children: [for (final s in labels) Text('#$s')]),
        ],
        const SizedBox(height: 16),
        Wrap(alignment: WrapAlignment.center, spacing: 8, children: [
          FilledButton.icon(onPressed: () => _say(), icon: const Icon(Icons.volume_up), label: const Text('发音')),
          OutlinedButton.icon(onPressed: () => _say(slow: true), icon: const Icon(Icons.slow_motion_video), label: const Text('慢速')),
          if (ex.isNotEmpty)
            OutlinedButton.icon(onPressed: () => _say(example: true), icon: const Icon(Icons.record_voice_over), label: const Text('读例句')),
          if (w.video != null)
            OutlinedButton.icon(onPressed: () => openVideo(context, w.word, w.video!), icon: const Icon(Icons.ondemand_video), label: const Text('视频讲解')),
        ]),
        if (widget.lang.code == 'en')
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              loading ? '正在联网获取真人发音、配图、例句…' : (info == null ? '离线模式：本地词库 + 手机语音' : '已联网补充，并缓存供离线使用'),
              textAlign: TextAlign.center,
              style: t.bodySmall,
            ),
          ),
        const SizedBox(height: 20),
        Text(w.zh, style: t.titleLarge, textAlign: TextAlign.center),
        if (def != null) ...[const SizedBox(height: 12), Text(def, textAlign: TextAlign.center)],
        if (ex.isNotEmpty) ...[const SizedBox(height: 12), Text(ex, textAlign: TextAlign.center, style: const TextStyle(fontStyle: FontStyle.italic))],
      ]),
    );
  }
}
