import 'package:flutter/material.dart';
import 'models.dart';
import 'speaker.dart';
import 'video_page.dart';

class WordPage extends StatelessWidget {
  final Word w;
  final Lang lang;
  const WordPage(this.w, this.lang, {super.key});

  Future<void> _say(BuildContext context, {bool slow = false, bool example = false}) async {
    final ok = example ? await Speaker.say(w.example, lang.tts) : await Speaker.play(w, lang.tts, slow: slow);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('手机缺少该语言的语音：系统设置 → 文字转语音 → 下载语音数据')));
    }
  }

  Widget _picture() {
    final emoji = Text(w.emoji, style: const TextStyle(fontSize: 96));
    final src = w.image;
    if (src == null) return emoji;
    return SizedBox(
      height: 160,
      child: src.startsWith('http')
          ? Image.network(src, errorBuilder: (_, __, ___) => emoji)
          : Image.asset(src, errorBuilder: (_, __, ___) => emoji),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(w.word)),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Center(child: _picture()),
        const SizedBox(height: 16),
        Center(child: Text(w.word, style: t.displaySmall)),
        if (w.ipa.isNotEmpty) Center(child: Text(w.ipa, style: t.titleLarge)),
        const SizedBox(height: 12),
        Wrap(alignment: WrapAlignment.center, spacing: 8, children: [for (final s in w.syllables) Chip(label: Text(s))]),
        const SizedBox(height: 16),
        Wrap(alignment: WrapAlignment.center, spacing: 8, children: [
          FilledButton.icon(onPressed: () => _say(context), icon: const Icon(Icons.volume_up), label: const Text('发音')),
          OutlinedButton.icon(onPressed: () => _say(context, slow: true), icon: const Icon(Icons.slow_motion_video), label: const Text('慢速')),
          if (w.example.isNotEmpty)
            OutlinedButton.icon(onPressed: () => _say(context, example: true), icon: const Icon(Icons.record_voice_over), label: const Text('读例句')),
          if (w.video != null)
            OutlinedButton.icon(onPressed: () => openVideo(context, w.word, w.video!), icon: const Icon(Icons.ondemand_video), label: const Text('视频讲解')),
        ]),
        const SizedBox(height: 24),
        Text(w.zh, style: t.headlineSmall, textAlign: TextAlign.center),
        if (w.example.isNotEmpty) ...[const SizedBox(height: 12), Text(w.example, textAlign: TextAlign.center)],
      ]),
    );
  }
}
