import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'models.dart';

/// mp4 直链在应用内播放；YouTube 等其他链接用系统/对应 App 打开。
Future<void> openVideo(BuildContext context, String title, String url) async {
  if (url.toLowerCase().contains('.mp4')) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(title, url)));
  } else {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
}

class VideoList extends StatelessWidget {
  final List<Lesson> lessons;
  const VideoList({super.key, required this.lessons});

  @override
  Widget build(BuildContext context) => ListView(children: [
        for (final v in lessons)
          ListTile(
            leading: const Icon(Icons.play_circle_fill, size: 36),
            title: Text(v.title),
            subtitle: Text(v.lang),
            onTap: () => openVideo(context, v.title, v.url),
          ),
      ]);
}

class VideoPage extends StatefulWidget {
  final String title, url;
  const VideoPage(this.title, this.url, {super.key});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late final VideoPlayerController c;
  bool err = false;

  @override
  void initState() {
    super.initState();
    c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    c.initialize().then((_) {
      if (mounted) {
        setState(() {});
        c.play();
      }
    }).catchError((_) {
      if (mounted) setState(() => err = true);
    });
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (err) {
      body = const Center(child: Text('视频加载失败（需要联网）'));
    } else if (!c.value.isInitialized) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      body = Column(children: [
        AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
        VideoProgressIndicator(c, allowScrubbing: true),
        IconButton(
          iconSize: 48,
          icon: Icon(c.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
          onPressed: () => setState(() {
            c.value.isPlaying ? c.pause() : c.play();
          }),
        ),
      ]);
    }
    return Scaffold(appBar: AppBar(title: Text(widget.title)), body: body);
  }
}
