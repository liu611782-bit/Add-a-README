import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// 英语分级：[显示名, 标签]
const levels = [
  ['全部', ''], ['小学', 'xx'], ['初中', 'zk'], ['高中', 'gk'], ['四级', 'cet4'], ['六级', 'cet6'],
  ['考研', 'ky'], ['雅思', 'ielts'], ['托福', 'toefl'], ['GRE', 'gre'], ['牛津3000', 'ox3000'],
  ['商务经济', 'd_biz'], ['计算机', 'd_it'], ['医学', 'd_med'], ['法律', 'd_law'], ['工程', 'd_eng'], ['科学', 'd_sci'],
];
final tagNames = {for (final x in levels) if (x[1].isNotEmpty) x[1]: x[0]};

class Lang {
  final String code, name, file, tts;
  Lang(this.code, this.name, this.file, this.tts);
}

class Lesson {
  final String title, lang, url;
  Lesson(this.title, this.lang, this.url);
}

class Word {
  final String word, ipa, zh, emoji, example, tags;
  final List<String> syllables;
  final String? image, audio, video;

  Word.fromJson(Map<String, dynamic> j)
      : word = j['word'],
        ipa = j['ipa'] ?? '',
        zh = j['zh'] ?? '',
        emoji = j['emoji'] ?? '🔤',
        example = j['example'] ?? '',
        tags = '',
        syllables = List<String>.from(j['syllables'] ?? [j['word']]),
        image = j['image'],
        audio = j['audio'],
        video = j['video'];

  Word.fromRow(Map<String, Object?> r)
      : word = r['word'] as String,
        ipa = (r['ipa'] ?? '') as String,
        zh = (r['zh'] ?? '') as String,
        emoji = '📘',
        example = '',
        tags = (r['tags'] ?? '') as String,
        syllables = ((r['syl'] ?? r['word']) as String).split('·'),
        image = null,
        audio = null,
        video = null;
}

/// 数据层：英语优先读内置 SQLite 大词库（打包时由 ECDICT 生成），其他语言读 assets/packs 的 JSON。
class PackRepo {
  static Database? _db;
  static bool _tried = false;

  static Future<Database?> _open() async {
    if (_tried) return _db;
    _tried = true;
    try {
      final ver = (await rootBundle.loadString('assets/db/version.txt')).trim();
      if (ver == 'none') return null;
      final path = p.join(await getDatabasesPath(), 'dict.db');
      await Directory(p.dirname(path)).create(recursive: true);
      final mark = File('$path.ver');
      if (!await File(path).exists() || !await mark.exists() || await mark.readAsString() != ver) {
        final data = await rootBundle.load('assets/db/dict.db');
        await File(path).writeAsBytes(data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes), flush: true);
        await mark.writeAsString(ver);
      }
      _db = await openDatabase(path, readOnly: true);
    } catch (_) {
      _db = null;
    }
    return _db;
  }

  static Future<List> _json(String f) async => jsonDecode(await rootBundle.loadString('assets/packs/$f')) as List;

  static Future<List<Lang>> langs() async =>
      (await _json('index.json')).map((e) => Lang(e['code'], e['name'], e['file'], e['tts'] ?? 'en-US')).toList();

  static Future<List<Lesson>> lessons() async =>
      (await _json('videos.json')).map((e) => Lesson(e['title'], e['lang'], e['url'])).toList();

  static Future<List<Word>> page(Lang l, {String level = '', String q = '', int offset = 0, int limit = 50}) async {
    if (l.code == 'en') {
      final d = await _open();
      if (d != null) {
        final where = <String>[];
        final args = <Object>[];
        if (level.isNotEmpty) {
          where.add('tags LIKE ?');
          args.add('% $level %');
        }
        if (q.isNotEmpty) {
          where.add('(word LIKE ? OR zh LIKE ?)');
          args.add('$q%');
          args.add('%$q%');
        }
        final rows = await d.query('words',
            where: where.isEmpty ? null : where.join(' AND '),
            whereArgs: args,
            orderBy: 'rank',
            limit: limit,
            offset: offset);
        return rows.map(Word.fromRow).toList();
      }
    }
    final all = (await _json(l.file)).map((e) => Word.fromJson(e as Map<String, dynamic>)).toList();
    final k = q.toLowerCase();
    return all.where((w) => w.word.toLowerCase().contains(k) || w.zh.contains(q)).skip(offset).take(limit).toList();
  }
}
