import 'dart:convert';
import 'package:flutter/services.dart';

class Lang {
  final String code, name, file, tts;
  Lang(this.code, this.name, this.file, this.tts);
}

class Lesson {
  final String title, lang, url;
  Lesson(this.title, this.lang, this.url);
}

class Word {
  final String word, ipa, zh, emoji, example;
  final List<String> syllables;
  final String? image, audio, video;

  Word.fromJson(Map<String, dynamic> j)
      : word = j['word'],
        ipa = j['ipa'] ?? '',
        zh = j['zh'] ?? '',
        emoji = j['emoji'] ?? '🔤',
        example = j['example'] ?? '',
        syllables = List<String>.from(j['syllables'] ?? [j['word']]),
        image = j['image'],
        audio = j['audio'],
        video = j['video'];
}

/// 读取 assets/packs 下的离线语言包与视频清单。
class PackRepo {
  static Future<List> _json(String f) async => jsonDecode(await rootBundle.loadString('assets/packs/$f')) as List;

  static Future<List<Lang>> langs() async =>
      (await _json('index.json')).map((e) => Lang(e['code'], e['name'], e['file'], e['tts'] ?? 'en-US')).toList();

  static Future<List<Word>> words(Lang l) async =>
      (await _json(l.file)).map((e) => Word.fromJson(e as Map<String, dynamic>)).toList();

  static Future<List<Lesson>> lessons() async =>
      (await _json('videos.json')).map((e) => Lesson(e['title'], e['lang'], e['url'])).toList();
}
