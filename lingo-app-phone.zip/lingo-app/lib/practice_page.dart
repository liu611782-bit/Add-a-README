import 'package:flutter/material.dart';
import 'models.dart';
import 'speaker.dart';

/// 听读练习：看图 → 听发音 → 跟读；可切纯听力、慢速、读例句。
class PracticePage extends StatefulWidget {
  final List<Word> words;
  final Lang lang;
  const PracticePage({super.key, required this.words, required this.lang});
  @override
  State<PracticePage> createState() => _PracticePageState();
}

class _PracticePageState extends State<PracticePage> {
  int i = 0;
  bool showText = true;
  Word get w => widget.words[i];

  Future<void> _say({bool slow = false, bool example = false}) async {
    final ok = example ? await Speaker.say(w.example, widget.lang.tts) : await Speaker.play(w, widget.lang.tts, slow: slow);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('手机缺少该语言的语音：系统设置 → 文字转语音 → 下载语音数据')));
    }
  }

  void _go(int d) {
    setState(() => i = (i + d) % widget.words.length);
    _say();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${i + 1} / ${widget.words.length}'),
          const SizedBox(height: 12),
          Text(w.emoji, style: const TextStyle(fontSize: 96)),
          const SizedBox(height: 12),
          Text(showText ? w.word : '？？？', style: t.displaySmall),
          if (showText) Text(w.syllables.join(' · '), style: t.titleLarge),
          if (showText && w.ipa.isNotEmpty) Text(w.ipa),
          if (showText) Text(w.zh, style: t.titleMedium),
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize: 36, onPressed: () => _go(-1), icon: const Icon(Icons.skip_previous)),
            IconButton.filled(iconSize: 36, onPressed: () => _say(), icon: const Icon(Icons.volume_up)),
            IconButton(iconSize: 36, onPressed: () => _say(slow: true), icon: const Icon(Icons.slow_motion_video)),
            IconButton(iconSize: 36, onPressed: () => _go(1), icon: const Icon(Icons.skip_next)),
          ]),
          if (w.example.isNotEmpty)
            TextButton.icon(onPressed: () => _say(example: true), icon: const Icon(Icons.record_voice_over), label: const Text('读例句')),
          SwitchListTile(
            title: const Text('显示拼写和释义（关 = 纯听力）'),
            value: showText,
            onChanged: (v) => setState(() => showText = v),
          ),
        ]),
      ),
    );
  }
}
