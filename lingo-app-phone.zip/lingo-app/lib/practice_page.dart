import 'package:flutter/material.dart';
import 'models.dart';
import 'speaker.dart';

/// 听读练习：看图/词 → 听发音 → 跟读；可切纯听力、慢速、读例句。
class PracticePage extends StatefulWidget {
  final Lang lang;
  final String level;
  const PracticePage({super.key, required this.lang, required this.level});
  @override
  State<PracticePage> createState() => _PracticePageState();
}

class _PracticePageState extends State<PracticePage> {
  List<Word>? words;
  int i = 0;
  bool showText = true;

  @override
  void initState() {
    super.initState();
    PackRepo.page(widget.lang, level: widget.level, limit: 100).then((v) {
      if (mounted) setState(() => words = v);
    });
  }

  Future<void> _say({bool slow = false, bool example = false}) async {
    final w = words![i];
    final ok = example ? await Speaker.say(w.example, widget.lang.tts) : await Speaker.playWord(w, widget.lang, slow: slow);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('手机缺少该语言的语音：系统设置 → 文字转语音 → 下载语音数据')));
    }
  }

  void _go(int d) {
    setState(() => i = (i + d) % words!.length);
    _say();
  }

  @override
  Widget build(BuildContext context) {
    final ws = words;
    if (ws == null) return const Center(child: CircularProgressIndicator());
    if (ws.isEmpty) return const Center(child: Text('这个分类暂时没有词'));
    final w = ws[i];
    final t = Theme.of(context).textTheme;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${i + 1} / ${ws.length}'),
          const SizedBox(height: 12),
          Text(w.emoji, style: const TextStyle(fontSize: 80)),
          const SizedBox(height: 12),
          Text(showText ? w.word : '？？？', style: t.displaySmall),
          if (showText) Text(w.syllables.join(' · '), style: t.titleLarge),
          if (showText && w.ipa.isNotEmpty) Text(w.ipa),
          if (showText) Text(w.zh.split('\n').first, style: t.titleMedium, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize: 36, onPressed: () => _go(-1), icon: const Icon(Icons.skip_previous)),
            IconButton.filled(iconSize: 36, onPressed: () => _say(), icon: const Icon(Icons.volume_up)),
            IconButton(iconSize: 36, onPressed: () => _say(slow: true), icon: const Icon(Icons.slow_motion_video)),
            IconButton(iconSize: 36, onPressed: () => _go(1), icon: const Icon(Icons.skip_next)),
          ]),
          if (w.example.isNotEmpty)
            TextButton.icon(onPressed: () => _say(example: true), icon: const Icon(Icons.record_voice_over), label: const Text('读例句')),
          SwitchListTile(
            title: const Text('显示拼写和释义（关 = 纯听力）'),
            value: showText,
            onChanged: (v) => setState(() => showText = v),
          ),
        ]),
      ),
    );
  }
}
