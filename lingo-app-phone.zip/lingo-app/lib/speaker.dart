import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'models.dart';
import 'online.dart';

class Speaker {
  static final _tts = FlutterTts();
  static final _player = AudioPlayer();

  /// 优先级：自带专业录音 → 已缓存的真人发音 → 联网下载真人发音 → 手机 TTS（离线兜底）
  static Future<bool> playWord(Word w, Lang l, {bool slow = false}) async {
    try {
      Source? src;
      if (w.audio != null) {
        src = AssetSource(w.audio!);
      } else if (l.code == 'en') {
        var path = await Online.cachedAudio(w.word);
        if (path == null) {
          final info = await Online.info(w.word);
          final url = info?['audio'] as String?;
          if (url != null) path = await Online.downloadAudio(w.word, url);
        }
        if (path != null) src = DeviceFileSource(path);
      }
      if (src != null) {
        await _player.setPlaybackRate(slow ? 0.6 : 1.0);
        await _player.play(src);
        return true;
      }
    } catch (_) {}
    return say(w.word, l.tts, rate: slow ? 0.25 : 0.45);
  }

  static Future<bool> say(String text, String locale, {double rate = 0.45}) async {
    try {
      if (await _tts.isLanguageAvailable(locale) != true) return false;
      await _tts.setLanguage(locale);
      await _tts.setSpeechRate(rate);
      await _tts.speak(text);
      return true;
    } catch (_) {
      return false;
    }
  }
}
