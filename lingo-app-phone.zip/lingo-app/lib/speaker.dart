import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'models.dart';

/// 发音：有专业录音就播录音，没有就用手机自带的语音合成（TTS）兜底。
class Speaker {
  static final _tts = FlutterTts();
  static final _player = AudioPlayer();

  static Future<bool> play(Word w, String locale, {bool slow = false}) async {
    final a = w.audio;
    if (a != null) {
      try {
        await _player.setPlaybackRate(slow ? 0.6 : 1.0);
        await _player.play(AssetSource(a));
        return true;
      } catch (_) {}
    }
    return say(w.word, locale, rate: slow ? 0.25 : 0.45);
  }

  static Future<bool> say(String text, String locale, {double rate = 0.45}) async {
    try {
      if (await _tts.isLanguageAvailable(locale) != true) return false;
      await _tts.setLanguage(locale);
      await _tts.setSpeechRate(rate);
      await _tts.speak(text);
      return true;
    } catch (_) {
      return false;
    }
  }
}
