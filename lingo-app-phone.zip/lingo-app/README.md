# Lingo — Android 多语言图文听读视频学习 App（离线 + 在线）

## 数据来源（全部开源/开放）
- **离线大词库**：打包时自动从 [ECDICT](https://github.com/skywind3000/ECDICT)（MIT）生成，含中文释义、音标、词频，
  并按 小学/初中/高中/四级/六级/考研/雅思/托福/GRE/牛津3000 分级；商务经济/计算机/医学/法律/工程/科学 按释义中的领域标记自动分类。
- **音节**：打包时用 pyphen（连字符词典）自动切分，仅供参考，须由语言专业人员审校。
- **联网补充**（结果自动缓存，之后离线可用）：[Free Dictionary API](https://dictionaryapi.dev/) 的真人发音/例句/英文释义；Wikipedia 配图（各图遵循其自身许可）。
- **离线发音**：手机自带 TTS（需在系统里下载语音数据）。把专业录音放进 `assets/audio/` 并在词条填 `audio`，会优先播放。
- 「视频资源」页收录 VOA、TED-Ed、Tatoeba、Wiktionary、Common Voice、Gutenberg 等链接，可自行增删（`assets/packs/videos.json`）。

## 其他语言
`assets/packs/<语言>.json` 小词库（示例），格式见各文件；新语言在 `index.json` 登记。

## 打包
`ci/build.sh` 由 GitHub Actions 调用：生成词库 → 生成 Android 工程 → 打 APK。
词库生成失败时自动回退到内置小词库，App 仍可使用。
