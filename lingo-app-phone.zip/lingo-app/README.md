# Lingo — Android 多语言图文听读视频学习 App

- 词汇：图片(emoji/图片)、IPA、音节、搜索，离线可用
- 听读：看图 → 听发音(专业录音优先，没有则用手机 TTS) → 跟读，可切纯听力、慢速、读例句
- 视频：mp4 直链应用内播放，YouTube 等链接跳转对应 App
- 内置 11 种语言示例：英、日、西、法、德、葡、俄、韩、阿、印地、泰

## 加内容（不用改代码）
- 词库 `assets/packs/<语言>.json`：word ipa syllables zh emoji example image audio video
- 新语言：加 json，并在 `assets/packs/index.json` 登记（tts 填系统语音代码，如 it-IT）
- 专业录音：放 `assets/audio/`（不要子文件夹），词条写 `"audio": "audio/en_apple.mp3"`
- 视频：`assets/packs/videos.json` 填 title / lang / url
- 示例词条的 IPA/音节仅作演示，须由语言专业人员审校
