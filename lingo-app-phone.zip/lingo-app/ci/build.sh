#!/bin/bash
# 由 GitHub Actions 调用：生成词库 -> 生成 Android 工程 -> 打包 APK
set -e
cd "$(dirname "$0")/.."
pip install pyphen >/dev/null 2>&1 || echo "pyphen 安装失败，音节将不自动切分"
python3 tools/build_dict.py || echo "词库生成失败，App 将使用内置小词库"
flutter create . --project-name lingo_app --org com.lingo --platforms=android
M=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' $M
sed -i 's#<queries>#<queries><intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>#' $M
sed -i 's#android:label="[^"]*"#android:label="Lingo 语言学习"#' $M
flutter pub get
flutter build apk --release
