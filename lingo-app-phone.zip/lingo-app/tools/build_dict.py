#!/usr/bin/env python3
"""打包时从开源词典 ECDICT (MIT, github.com/skywind3000/ECDICT) 生成离线词库 assets/db/dict.db。"""
import csv, os, re, sqlite3, subprocess, time

csv.field_size_limit(10**8)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.environ.get('OUT_DIR', os.path.join(ROOT, 'assets', 'db'))
SRC = os.environ.get('ECDICT_DIR', '/tmp/ECDICT')
KNOWN = {'zk', 'gk', 'cet4', 'cet6', 'ky', 'toefl', 'ielts', 'gre'}
# 释义里的领域标记 -> 职业/专业分类
DOMS = {'计': 'd_it', '经': 'd_biz', '商': 'd_biz', '医': 'd_med', '药': 'd_med', '法': 'd_law',
        '机': 'd_eng', '电': 'd_eng', '建': 'd_eng', '工': 'd_eng',
        '物': 'd_sci', '化': 'd_sci', '数': 'd_sci', '生': 'd_sci', '地': 'd_sci'}


def num(x):
    try:
        return int(float(x))
    except Exception:
        return 0


def main():
    os.makedirs(OUT, exist_ok=True)
    if not os.path.exists(os.path.join(SRC, 'ecdict.csv')):
        subprocess.check_call(['git', 'clone', '--depth', '1', 'https://github.com/skywind3000/ECDICT', SRC])
    try:
        import pyphen
        hy = pyphen.Pyphen(lang='en_US')
    except Exception:
        hy = None
    tmp = os.path.join(OUT, 'dict.db.tmp')
    if os.path.exists(tmp):
        os.remove(tmp)
    seen, rows, stat = set(), [], {}
    with open(os.path.join(SRC, 'ecdict.csv'), encoding='utf-8', newline='') as f:
        for r in csv.DictReader(f):
            w = (r.get('word') or '').strip()
            if not re.fullmatch(r"[A-Za-z][A-Za-z'-]*", w) or w.lower() in seen:
                continue
            tr = (r.get('translation') or '').replace('\\n', '\n').strip()
            if not tr:
                continue
            frq, bnc = num(r.get('frq')), num(r.get('bnc'))
            rank = frq if frq > 0 else (bnc if bnc > 0 else 10**6)
            tag = set((r.get('tag') or '').split()) & KNOWN
            ox = (r.get('oxford') or '').strip() == '1'
            dom = set()
            if rank <= 60000:
                dom = {DOMS[m[0]] for m in re.findall(r'\[([^\]]{1,4})\]', tr) if m[0] in DOMS}
            if not (tag or ox or rank <= 30000 or dom):
                continue
            tags = set(tag) | dom
            if ox:
                tags.add('ox3000')
            if 'zk' in tag and rank <= 1500:
                tags.add('xx')  # 小学：中考词汇里最常用的一批（近似，可用官方小学词表替换）
            lines = [x.strip() for x in tr.split('\n') if x.strip()][:4]
            ph = (r.get('phonetic') or '').strip()
            syl = hy.inserted(w, hyphen='·') if hy and len(w) > 3 else w
            seen.add(w.lower())
            rows.append((w, '/%s/' % ph if ph else '', '\n'.join(lines)[:160], syl,
                         ' ' + ' '.join(sorted(tags)) + ' ', rank))
            for t in tags:
                stat[t] = stat.get(t, 0) + 1
    rows.sort(key=lambda x: x[5])
    db = sqlite3.connect(tmp)
    db.execute('CREATE TABLE words(word TEXT, ipa TEXT, zh TEXT, syl TEXT, tags TEXT, rank INTEGER)')
    db.executemany('INSERT INTO words VALUES (?,?,?,?,?,?)', rows)
    db.execute('CREATE INDEX i_word ON words(word COLLATE NOCASE)')
    db.execute('CREATE INDEX i_rank ON words(rank)')
    db.commit()
    db.execute('VACUUM')
    db.close()
    os.replace(tmp, os.path.join(OUT, 'dict.db'))
    with open(os.path.join(OUT, 'version.txt'), 'w') as vf:
        vf.write(str(int(time.time())))
    print('words:', len(rows), 'size MB:', round(os.path.getsize(os.path.join(OUT, 'dict.db')) / 1e6, 1))
    print('per tag:', dict(sorted(stat.items())))
    print('syllables:', 'pyphen' if hy else 'none')


if __name__ == '__main__':
    main()
